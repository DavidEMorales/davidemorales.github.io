A Very Hard Game

Created by David Morales

All credits go to Unity Standard Assets.

To complete each level, you must collect all the coins and get to the portal at the end.
There are six levels in total, all increasing in difficulty.

Use WASD or the arrow keys to move and space bar to jump. Press R to restart the game.
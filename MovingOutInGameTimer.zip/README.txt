1. Extract the MovingOutInGameTimer folder to any location on your computer
2. Make sure your run recording only includes levels that are part of your run (don't include any levels before your run's timer starts)
3. Make sure your run is fullscreen.
4. Place your run recording in the 'run' folder
5. Run the MovingOutInGameTimer.exe (you may need to run as administrator)
6. Your results will be generated and placed in the run/output.txt file
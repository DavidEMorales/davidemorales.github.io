1. Extract the Moving Out 2P Host folder somewhere.
2. Launch Moving Out.
3. Launch the Moving Out Unity Client.exe under Input Manager.
4. Launch the MovingOutCommunication.exe under Console.
5. **This is very important.** When finished playing, make sure to close Moving Out, THEN Moving Out Unity Client, THEN MovingOutCommunication. If you close the console before closing either of the other two, Unity will crash and will not close until you restart your computer. This is a bug with Unity itself, so it cannot be fixed (and why it persists even in a full Unity game like Moving Out).